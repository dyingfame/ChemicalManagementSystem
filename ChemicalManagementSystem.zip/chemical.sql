/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50624
Source Host           : localhost:3306
Source Database       : chemical

Target Server Type    : MYSQL
Target Server Version : 50624
File Encoding         : 65001

Date: 2015-05-28 17:57:26
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `adddrug`
-- ----------------------------
DROP TABLE IF EXISTS `adddrug`;
CREATE TABLE `adddrug` (
  `drugName` varchar(20) NOT NULL,
  `drugCount` double NOT NULL,
  PRIMARY KEY (`drugName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of adddrug
-- ----------------------------
INSERT INTO `adddrug` VALUES ('硝酸', '20');

-- ----------------------------
-- Table structure for `drugstock`
-- ----------------------------
DROP TABLE IF EXISTS `drugstock`;
CREATE TABLE `drugstock` (
  `drugName` varchar(20) NOT NULL,
  `drugCount` double NOT NULL,
  `drugLimit` double NOT NULL,
  `drugLight` varchar(20) NOT NULL,
  `drugVolat` varchar(20) NOT NULL,
  `remark` varchar(20) DEFAULT NULL,
  `drugUnitPrice` double NOT NULL,
  PRIMARY KEY (`drugName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of drugstock
-- ----------------------------
INSERT INTO `drugstock` VALUES ('乙醚', '27', '2', '可见光', '易挥发', '腊封', '41');
INSERT INTO `drugstock` VALUES ('二硫化碳', '24', '0.5', '可见光', '不挥发', '水封', '32');
INSERT INTO `drugstock` VALUES ('氢氧化钠', '10', '0.5', '可见光', '不挥发', null, '12.1');
INSERT INTO `drugstock` VALUES ('氨水', '4', '1', '可见光', '易挥发', '液面滴油', '10');
INSERT INTO `drugstock` VALUES ('水', '23', '32', '可见光', '不挥发', '', '1');
INSERT INTO `drugstock` VALUES ('盐酸', '2', '2.5', '可见光', '易挥发', null, '5.2');
INSERT INTO `drugstock` VALUES ('碳酸', '20', '2', '可见光', '易挥发', '', '2');
INSERT INTO `drugstock` VALUES ('过氧化钠', '32', '1', '可见光', '不挥发', '腊封', '23');

-- ----------------------------
-- Table structure for `useregister`
-- ----------------------------
DROP TABLE IF EXISTS `useregister`;
CREATE TABLE `useregister` (
  `userName` varchar(20) NOT NULL,
  `userNum` varchar(20) NOT NULL,
  `drugName` varchar(20) NOT NULL,
  `drugCount` double NOT NULL,
  `date` varchar(20) NOT NULL,
  `record` varchar(20) NOT NULL,
  PRIMARY KEY (`record`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of useregister
-- ----------------------------
INSERT INTO `useregister` VALUES ('闫树东', '1', '二硫化碳', '0.2', '2015-05-26', '201505276004300000');
INSERT INTO `useregister` VALUES ('闫树东', '1', '氢氧化钠', '0.1', '2015-05-26', '201505276005400001');
INSERT INTO `useregister` VALUES ('李泽强', '131110210', '乙醚', '1', '2015-05-28', '2015052815021400000');
